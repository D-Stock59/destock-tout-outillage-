function showAlert() {
    alert("Merci de votre visite !");
}
